import org.mindrot.jbcrypt.BCrypt;
public class Main
{
    public static void main(String[] args)
    {
        //String password = "test";
        //String candidate = "test";
        //String hashed = BCrypt.hashpw(password, BCrypt.gensalt());
        //String hashed = BCrypt.hashpw(password, BCrypt.gensalt(12));

        //if (BCrypt.checkpw(candidate, hashed)) System.out.println("It matches");

       // else System.out.println("It does not match");
        Menu menu = new Menu();
        menu.Menu();
    }

}

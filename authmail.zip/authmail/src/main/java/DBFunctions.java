import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import org.mindrot.jbcrypt.BCrypt;
public class DBFunctions
{
    public int getAtt()
    {
        return att;
    }

    private int att = 3;
    private boolean check1, check2, check3;
    private String password_s;
    public Connection connect_to_sql(String dbname, String user, String pass)
    {
        Connection conn = null;
        try
        {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/"+ dbname,user,pass);
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
        return conn;
    }
    public void createTable(Connection conn, String table_name)
    {
        Statement statement;
        try
        {
            String query="create table "+table_name+"(id SERIAL,login varchar(200),iin varchar(200), password varchar(200),primary key(id))";
            statement = conn.createStatement();
            statement.executeUpdate(query);
            System.out.println("Table created.");
        }
        catch(Exception e)
        {
            System.out.println(e);
        }

    }

    public void update_password(Connection conn,String table_name,String new_pass, String login)
    {
        Statement statement;
        try
        {
            String hashedd = BCrypt.hashpw(new_pass, BCrypt.gensalt());
            String query=String.format("update %s set password ='%s' where login = '%s'",table_name, hashedd, login);
            statement = conn.createStatement();
            statement.executeUpdate(query);
            System.out.println("Password changed.");
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
    public void registration(Connection conn,String table_name, String login, String iin, char[] password)
    {
        Statement statement;
        try
        {
            password_s = "";
            check1 = false;
            check2 = false;
            check3 = false;
            if (password.length > 6)
            {
                for (int k = 0; k < password.length; k++)
                {
                    if (password[k] >= 48 && password[k] <= 57)
                    {
                        check1 = true;
                    } else if (password[k] >= 65 && password[k] <= 90)
                    {
                        check2 = true;
                    } else if (password[k] >= 97 && password[k] <= 122)
                    {
                        check3 = true;
                    }
                }
                if ((check1) && (check2) && (check3))
                {
                    for (int l = 0; l < password.length; l++) {
                        password_s += password[l];
                    }
                    String hashed = BCrypt.hashpw(password_s, BCrypt.gensalt());
                    String query=String.format("insert into %s(login, iin, password) values('%s','%s','%s');",table_name,login,iin,hashed);
                    statement = conn.createStatement();
                    statement.executeUpdate(query);
                    System.out.println("Registration successful!");
                }
                else
                {
                    System.out.println("Registration error.Your password must be longed than 6 symbols, include at least one capital letter, lower letter and digit.");
                }
            }
            else
            {
                System.out.println("Registration error.Your password must be longed than 6 symbols, include at least one capital letter, lower letter and digit.");
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
    public void login(Connection conn,String table_name,String login,String password)
    {
        Statement statement;
        ResultSet rs=null;
        try
        {
            String query=String.format("select * from %s",table_name);
            statement = conn.createStatement();
            rs = statement.executeQuery(query);
            boolean loggedIn = false;
            while (rs.next())
            {
                if (login.equals(rs.getString("login")) && BCrypt.checkpw(password, rs.getString("password")))
                {
                    System.out.println("Login successful!");
                    att = 3;
                    loggedIn = true;
                    break;
                }
            }
            if(!loggedIn)
            {
                att--;
                System.out.println("Invalid username or password. Attempts left:" + att);
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
    public void login_iin(Connection conn,String table_name,String iin,String password)
    {
        Statement statement;
        ResultSet rs=null;
        try
        {
            String query=String.format("select * from %s",table_name);
            statement = conn.createStatement();
            rs = statement.executeQuery(query);
            boolean loggedIn2 = false;
            while (rs.next())
            {
                if (iin.equals(rs.getString("iin")) && BCrypt.checkpw(password, rs.getString("password")))
                {
                    System.out.println("Login successful!");
                    att = 3;
                    loggedIn2 = true;
                    break;
                }
            }
            if(loggedIn2 == false)
            {
                att--;
                System.out.println("Invalid username or password. Attempts left:" + att);
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

    public boolean search_db(Connection conn,String table_name,String login)
    {
        Statement statement;
        ResultSet rs=null;
        String result = "";
        try
        {
            String query=String.format("select * from %s",table_name);
            statement = conn.createStatement();
            rs = statement.executeQuery(query);
            while (rs.next()) {
                if (login.equals(rs.getString("login")))
                {
                    return true;
                }
            }
        }
        catch(Exception e)
        {
            return false;
        }
        return false;
    }
}

import java.sql.Connection;
import java.util.Scanner;


public class Application {
    DBFunctions db = new DBFunctions();
    EmailSender es = new EmailSender();
    Connection conn = db.connect_to_sql("authmail", "postgres", "qwerty");
    Scanner input = new Scanner(System.in);

    private char[] password_reg;
    private boolean loginPermission = false;
    private String login_log;
    private String password_log;
    private String login_rec;
    private String password_rec;
    private String login_reg;
    private String iin_reg;
    private String iin_log;


    public void Register()
    {
        System.out.println("Enter your email:");
        login_reg = input.next();
        System.out.println("Enter your IIN:");
        iin_reg = input.next();
        System.out.println("Create password:");
        password_reg = input.next().toCharArray();
        db.registration(conn, "users", login_reg, iin_reg, password_reg);
    }
    public void Login()
    {
        if(db.getAtt() > 0)
        {
            System.out.println("Enter your email:");
            login_log = input.next();
            System.out.println("Enter password:");
            password_log = input.next();
            db.login(conn,"users", login_log, password_log);
        }
        else
        {
            System.out.println("0 attempts left. Blocked.");
            System.exit(0);
        }
    }
    public void LoginIIN()
    {
        if(db.getAtt() > 0)
        {
            System.out.println("Enter your IIN:");
            iin_log = input.next();
            System.out.println("Enter password:");
            password_log = input.next();
            db.login_iin(conn, "users", iin_log, password_log);
        }
        else
        {
            System.out.println("0 attempts left. Blocked.");
            System.exit(0);
        }
    }
    public void Recover()
        {

                System.out.println("Enter email for recovery:");
                login_rec = input.next();
                if (db.search_db(conn, "users", login_rec) == true)
                {
                    if (es.EmailSender(login_rec)) {
                        System.out.println("Create a new password:");
                        password_rec = input.next();
                        db.update_password(conn, "users", password_rec, login_rec);
                    } else {
                        System.out.println("Wrong code. Try again.");
                    }
                }
                else {
                    System.out.println("This account has not registered yet.");
                }
        }
}


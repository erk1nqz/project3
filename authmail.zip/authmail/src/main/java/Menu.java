import java.util.Scanner;

public class Menu {
    public void Menu() {
        Application application = new Application();

        Scanner input = new Scanner(System.in);

        label:
        while (true) {
            System.out.println("-------------------------------");
            System.out.println("1.Register a new account");
            System.out.println("2.Login with email");
            System.out.println("3.Login with IIN");
            System.out.println("4.Recover");
            System.out.println("5.Exit");
            System.out.println("-------------------------------");

            String choose = input.next();

            switch (choose) {
                case "1":
                    application.Register();
                    break;
                case "2":
                    application.Login();
                    break;
                case "3":
                    application.LoginIIN();
                    break;
                case "4":
                    application.Recover();
                    break;
                case "5":
                    break label;
                default:
                    System.out.println("Unknown operation.");
                    break;
            }
        }
    }
}